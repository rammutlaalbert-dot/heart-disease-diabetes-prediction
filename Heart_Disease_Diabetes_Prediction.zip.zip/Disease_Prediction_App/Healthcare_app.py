import streamlit as st
import joblib
import numpy as np
import pandas as pd

heart_model = joblib.load("heart_disease_model.pkl")
heart_scaler = joblib.load("heart_scaler.pkl")  
diabetes_model = joblib.load("diabetes_model.pkl")
diabetes_scaler = joblib.load("diabetes_scaler.pkl")

st.set_page_config(page_title="Healthcare Disease Risk Prediction", page_icon="🏥", layout="centered")

st.title("🏥 Healthcare Disease Risk Prediction")
st.write("This application uses machine learning to estimate a patient's risk of diabetes and heart disease based on health information.")

st.markdown("---")

choice = st.radio("What would you like to predict?", ["Diabetes", "Heart Disease", "Both"])

if choice == "Diabetes":

    st.subheader("Diabetes Risk Prediction")

    pregnancies = st.number_input(
        "Pregnancies", min_value=0, max_value=20, value=0
    )

    glucose = st.number_input(
        "Glucose", min_value=0, max_value=300, value=100
    )

    blood_pressure = st.number_input(
        "Blood Pressure", min_value=0, max_value=200, value=70
    )

    skin_thickness = st.number_input(
        "Skin Thickness", min_value=0, max_value=100, value=20
    )

    bmi = st.number_input(
        "BMI", min_value=0.0, max_value=70.0, value=25.0
    )

    dpf = st.number_input(
        "Diabetes Pedigree Function", min_value=0.0, max_value=3.0, value=0.5
    )

    age = st.number_input(
        "Age", min_value=1, max_value=120, value=30
    )

    if st.button("Predict Diabetes"):

        input_data = np.array([[
            pregnancies,
            glucose,
            blood_pressure,
            skin_thickness,
            bmi,
            dpf,
            age
        ]])
        input_data = diabetes_scaler.transform(input_data) 
        prediction = diabetes_model.predict(input_data)


        st.markdown("---")                          
        st.subheader("Prediction Results") 

        if prediction[0] == 1:
            st.error("🩺 High Risk of Diabetes")
        else:
            st.success("🩺 Low Risk of Diabetes")


elif choice == "Heart Disease":

    st.subheader("Heart Disease Risk Prediction")

    hd_age = st.number_input(
        "Age", min_value=1, max_value=120, value=40
    )

    sex = st.selectbox(
        "Sex", ["Male", "Female"]
    )

    cp = st.selectbox(
        "Chest Pain Type",
        ["typical angina", "atypical angina", "non-anginal", "asymptomatic"]
    )

    trestbps = st.number_input(
        "Resting Blood Pressure",
        min_value=0,
        max_value=250,
        value=120
    )

    chol = st.number_input(
        "Cholesterol",
        min_value=0,
        max_value=700,
        value=200
    )

    fbs = st.selectbox(
        "Fasting Blood Sugar > 120 mg/dl",
        ["True", "False"]
    )

    restecg = st.selectbox(
        "Resting ECG Results",
        ["normal", "st-t abnormality", "lv hypertrophy"]
    )

    thalch = st.number_input(
        "Max Heart Rate Achieved",
        min_value=0,
        max_value=250,
        value=150
    )

    exang = st.selectbox(
        "Exercise-Induced Angina",
        ["True", "False"]
    )

    oldpeak = st.number_input(
        "ST Depression (oldpeak)",
        min_value=-3.0,
        max_value=7.0,
        value=0.0
    )

    slope = st.selectbox(
        "Slope of Peak Exercise ST Segment",
        ["upsloping", "flat", "downsloping"]
    )

    thal = st.selectbox(
        "Thalassemia",
        ["normal", "fixed defect", "reversible defect"]
    )

    # IMPORTANT: this button is INSIDE the Heart Disease section
    if st.button("Predict Heart Disease"):

        sex_val = 1 if sex == "Male" else 0
        fbs_val = 1 if fbs == "True" else 0
        exang_val = 1 if exang == "True" else 0

        cp_atypical = 1 if cp == "atypical angina" else 0
        cp_nonanginal = 1 if cp == "non-anginal" else 0
        cp_typical = 1 if cp == "typical angina" else 0

        restecg_normal = 1 if restecg == "normal" else 0
        restecg_sttab = 1 if restecg == "st-t abnormality" else 0

        slope_flat = 1 if slope == "flat" else 0
        slope_up = 1 if slope == "upsloping" else 0

        thal_normal = 1 if thal == "normal" else 0
        thal_reversible = 1 if thal == "reversible defect" else 0

        input_data = np.array([[
            hd_age,
            sex_val,
            trestbps,
            chol,
            fbs_val,
            thalch,
            exang_val,
            oldpeak,
            cp_atypical,
            cp_nonanginal,
            cp_typical,
            restecg_normal,
            restecg_sttab,
            slope_flat,
            slope_up,
            thal_normal,
            thal_reversible
        ]])
        input_data = heart_scaler.transform(input_data)  
        prediction = heart_model.predict(input_data)

        st.markdown("---")                          
        st.subheader("Prediction Results") 

        if prediction[0] == 1:
            st.error("❤️ High Risk of Heart Disease")
        else:
            st.success("❤️ Low Risk of Heart Disease")

elif choice == "Both":

    st.subheader("Diabetes and Heart Disease Risk Prediction")

    st.write("Please enter the patient's information below.")

    # -------------------------
    # DIABETES INFORMATION
    # -------------------------

    st.markdown("### 🩺 Diabetes Information")

    pregnancies = st.number_input(
        "Pregnancies",
        min_value=0,
        max_value=20,
        value=0,
        key="both_pregnancies"
    )

    glucose = st.number_input(
        "Glucose",
        min_value=0,
        max_value=300,
        value=100,
        key="both_glucose"
    )

    diabetes_blood_pressure = st.number_input(
        "Blood Pressure (Diabetes)",
        min_value=0,
        max_value=200,
        value=70,
        key="both_diabetes_bp"
    )

    skin_thickness = st.number_input(
        "Skin Thickness",
        min_value=0,
        max_value=100,
        value=20,
        key="both_skin"
    )

    bmi = st.number_input(
        "BMI",
        min_value=0.0,
        max_value=70.0,
        value=25.0,
        key="both_bmi"
    )

    dpf = st.number_input(
        "Diabetes Pedigree Function",
        min_value=0.0,
        max_value=3.0,
        value=0.5,
        key="both_dpf"
    )

    both_age = st.number_input(
        "Age",
        min_value=1,
        max_value=120,
        value=40,
        key="both_age"
    )


    # -------------------------
    # HEART DISEASE INFORMATION
    # -------------------------

    st.markdown("### ❤️ Heart Disease Information")

    sex = st.selectbox(
        "Sex",
        ["Male", "Female"],
        key="both_sex"
    )

    cp = st.selectbox(
        "Chest Pain Type",
        [
            "typical angina",
            "atypical angina",
            "non-anginal",
            "asymptomatic"
        ],
        key="both_cp"
    )

    trestbps = st.number_input(
        "Resting Blood Pressure",
        min_value=0,
        max_value=250,
        value=120,
        key="both_trestbps"
    )

    chol = st.number_input(
        "Cholesterol",
        min_value=0,
        max_value=700,
        value=200,
        key="both_chol"
    )

    fbs = st.selectbox(
        "Fasting Blood Sugar > 120 mg/dl",
        ["True", "False"],
        key="both_fbs"
    )

    restecg = st.selectbox(
        "Resting ECG Results",
        [
            "normal",
            "st-t abnormality",
            "lv hypertrophy"
        ],
        key="both_restecg"
    )

    thalch = st.number_input(
        "Max Heart Rate Achieved",
        min_value=0,
        max_value=250,
        value=150,
        key="both_thalch"
    )

    exang = st.selectbox(
        "Exercise-Induced Angina",
        ["True", "False"],
        key="both_exang"
    )

    oldpeak = st.number_input(
        "ST Depression (oldpeak)",
        min_value=-3.0,
        max_value=7.0,
        value=0.0,
        key="both_oldpeak"
    )

    slope = st.selectbox(
        "Slope of Peak Exercise ST Segment",
        [
            "upsloping",
            "flat",
            "downsloping"
        ],
        key="both_slope"
    )

    thal = st.selectbox(
        "Thalassemia",
        [
            "normal",
            "fixed defect",
            "reversible defect"
        ],
        key="both_thal"
    )


    # -------------------------
    # PREDICT BOTH
    # -------------------------

    if st.button("🔍 Predict Both Diseases"):

        # ===== DIABETES =====

        diabetes_input = np.array([[
            pregnancies,
            glucose,
            diabetes_blood_pressure,
            skin_thickness,
            bmi,
            dpf,
            both_age
        ]])

        diabetes_input = diabetes_scaler.transform(diabetes_input)

        diabetes_prediction = diabetes_model.predict(diabetes_input)


        # ===== HEART DISEASE =====

        sex_val = 1 if sex == "Male" else 0
        fbs_val = 1 if fbs == "True" else 0
        exang_val = 1 if exang == "True" else 0

        cp_atypical = 1 if cp == "atypical angina" else 0
        cp_nonanginal = 1 if cp == "non-anginal" else 0
        cp_typical = 1 if cp == "typical angina" else 0

        restecg_normal = 1 if restecg == "normal" else 0
        restecg_sttab = 1 if restecg == "st-t abnormality" else 0

        slope_flat = 1 if slope == "flat" else 0
        slope_up = 1 if slope == "upsloping" else 0

        thal_normal = 1 if thal == "normal" else 0
        thal_reversible = 1 if thal == "reversible defect" else 0

        heart_input = np.array([[
            both_age,
            sex_val,
            trestbps,
            chol,
            fbs_val,
            thalch,
            exang_val,
            oldpeak,
            cp_atypical,
            cp_nonanginal,
            cp_typical,
            restecg_normal,
            restecg_sttab,
            slope_flat,
            slope_up,
            thal_normal,
            thal_reversible
        ]])
        heart_input = heart_scaler.transform(heart_input)
        heart_prediction = heart_model.predict(heart_input)
        

        # -------------------------
        # DISPLAY RESULTS
        # -------------------------

        st.markdown("---")
        st.subheader("Prediction Results")

        # Diabetes result
        if diabetes_prediction[0] == 1:
            st.error("🩺 **High Risk of Diabetes**")
        else:
            st.success("🩺 **Low Risk of Diabetes**")

        # Heart disease result
        if heart_prediction[0] == 1:
            st.error("❤️ **High Risk of Heart Disease**")
        else:
            st.success("❤️ **Low Risk of Heart Disease**")